package assign2;

public final class HTTPStatusCode
{
	/* Status codes */
	public static String s200 = "200 OK";
	public static String s204 = "204 No content";
	public static String s400 = "400 Bad Request";
	public static String s403 = "403 Access Denied";
	public static String s404 = "404 Not Found";
	public static String s411 = "411 Length Required";
	public static String s413 = "413 Request Entity Too Large";
	public static String s415 = "415 Unsupported Media Type";
	public static String s418 = "418 I'm a teapot";
	public static String s500 = "500 Internal Server Error";
	
	/**
	 * createPage
	 * <p>
	 * Creates a HTML Page
	 * @param statusCode - HTML Status code
	 * @return - the page as a byte array
	 */
	public static byte[] createPage(String statusCode)
	{
		String body = "<!DOCTYPE html>\r\n"
				+ "<html>\r\n"
				+ "\t<body>\r\n"
				+ "\t\t<title>" + statusCode + "</title>\r\n"
				+ "\t\t<h1>" + statusCode + "</h1>\r\n"
				+ "\t</body>\r\n"
				+ "</html>\r\n";
				
		
		String header = new String(
				"HTTP/1.1 " + statusCode + "\r\n" +
				"Content-Length: " + body.length() +
				"\r\n\r\n");
		
			String page = header + body;
			return page.getBytes();

	}
	/**
	 * createPage
	 * <p>
	 * Creates a HTML Page
	 * @param statusCode - HTML Status code
	 * @param title - Page title
	 * @param content - Page content
	 * @return - the page as a byte array
	 */
	public static byte[] createPage(String statusCode, String title, String content)
	{
		String body = "<!DOCTYPE html>\r\n"
				+ "<html>\r\n"
				+ "\t<body>\r\n" 
				+ "\t\t<title>" + title + "</title>\r\n"
				+ "\t\t<h1>" + content + "</h1>\r\n"
				+ "\t</body>\r\n"
				+ "</html>\r\n";
		
		String header = new String(
				"HTTP/1.1 " + statusCode + "\r\n" +
				"Content-Length: " + body.length() +
				"\r\n\r\n");
		
			String page = header + body;
			return page.getBytes();

	}
	
	/**
	 * getHeader
	 * <p>
	 * Creates a HTTP Header
	 * @param statusCode - HTML Status code
	 * @param length - Page length
	 * @return - header as byte array
	 */
	public static byte[] getHeader(String statusCode, int length)
	{
		return new String(
				"HTTP/1.1 " + statusCode + "\r\n"
				+ "Content-Length: " + length 
				+ "\r\n\r\n").getBytes();
	}

}
